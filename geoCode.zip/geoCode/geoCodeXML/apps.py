from django.apps import AppConfig


class GeocodexmlConfig(AppConfig):
    name = 'geoCodeXML'
